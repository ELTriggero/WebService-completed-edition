﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace provaServizio
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void label1_Click(object sender, EventArgs e)
    {

    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void btnSomma_Click(object sender, EventArgs e)
    {
      int a = int.Parse(txtN1.Text);
      int b = int.Parse(txtN2.Text);

      WS.SommaSoapClient client =
        new WS.SommaSoapClient();
      int somma = client.SommaDueNumeri(a, b);
      MessageBox.Show(somma.ToString());
    }

    private void btnMoltiplica_Click(object sender, EventArgs e)
    {
      int a = int.Parse(txtN1.Text);
      int b = int.Parse(txtN2.Text);

      WS.SommaSoapClient client =
        new WS.SommaSoapClient();
      int prodotto = client.MoltiplicazioneDueNumeri(a, b);
      MessageBox.Show(prodotto.ToString());
    }
  }
}
