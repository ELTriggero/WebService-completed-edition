﻿namespace provaServizio
{
  partial class Form1
  {
    /// <summary>
    /// Variabile di progettazione necessaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Pulire le risorse in uso.
    /// </summary>
    /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Codice generato da Progettazione Windows Form

    /// <summary>
    /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
    /// il contenuto del metodo con l'editor di codice.
    /// </summary>
    private void InitializeComponent()
    {
      this.btnSomma = new System.Windows.Forms.Button();
      this.txtN1 = new System.Windows.Forms.TextBox();
      this.txtN2 = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.btnMoltiplica = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // btnSomma
      // 
      this.btnSomma.Location = new System.Drawing.Point(105, 132);
      this.btnSomma.Name = "btnSomma";
      this.btnSomma.Size = new System.Drawing.Size(100, 23);
      this.btnSomma.TabIndex = 0;
      this.btnSomma.Text = "somma";
      this.btnSomma.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
      this.btnSomma.UseVisualStyleBackColor = true;
      this.btnSomma.Click += new System.EventHandler(this.btnSomma_Click);
      // 
      // txtN1
      // 
      this.txtN1.Location = new System.Drawing.Point(105, 48);
      this.txtN1.Name = "txtN1";
      this.txtN1.Size = new System.Drawing.Size(100, 20);
      this.txtN1.TabIndex = 1;
      // 
      // txtN2
      // 
      this.txtN2.Location = new System.Drawing.Point(105, 89);
      this.txtN2.Name = "txtN2";
      this.txtN2.Size = new System.Drawing.Size(100, 20);
      this.txtN2.TabIndex = 2;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(13, 51);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(70, 13);
      this.label1.TabIndex = 3;
      this.label1.Text = "primo numero";
      this.label1.Click += new System.EventHandler(this.label1_Click);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(13, 96);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(86, 13);
      this.label2.TabIndex = 4;
      this.label2.Text = "secondo numero";
      // 
      // btnMoltiplica
      // 
      this.btnMoltiplica.Location = new System.Drawing.Point(105, 161);
      this.btnMoltiplica.Name = "btnMoltiplica";
      this.btnMoltiplica.Size = new System.Drawing.Size(100, 23);
      this.btnMoltiplica.TabIndex = 5;
      this.btnMoltiplica.Text = "moltiplicazione";
      this.btnMoltiplica.UseVisualStyleBackColor = true;
      this.btnMoltiplica.Click += new System.EventHandler(this.btnMoltiplica_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(284, 261);
      this.Controls.Add(this.btnMoltiplica);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.txtN2);
      this.Controls.Add(this.txtN1);
      this.Controls.Add(this.btnSomma);
      this.Name = "Form1";
      this.Text = "Form1";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button btnSomma;
    private System.Windows.Forms.TextBox txtN1;
    private System.Windows.Forms.TextBox txtN2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Button btnMoltiplica;
  }
}

