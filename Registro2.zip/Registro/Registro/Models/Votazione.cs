﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Registro.Models
{
  public class Votazione
  {
    public string Allievo { get; set; }
    public int Voto { get; set; }
    public int Peso { get; set; }
  }
}