﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProvaWS
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      Converter.ConverterSoapClient client =
        new Converter.ConverterSoapClient();

      string[] cur = client.GetCurrencies();
      
      foreach (string c in cur)
        cmbCurrencies.Items.Add(c);
    }

    private void btnConverti_Click(object sender, EventArgs e)
    {
      Converter.ConverterSoapClient client =
        new Converter.ConverterSoapClient();

      string ValutaTo = cmbCurrencies.SelectedItem.ToString();
      double Importo = double.Parse(txtImporto.Text);

      decimal conv = client.GetConversionRate(
        "EUR", ValutaTo, DateTime.Today.AddDays(-1));

      double ImportoConv = Importo * (double)conv;
      MessageBox.Show(ImportoConv.ToString());
    }
  }
}
